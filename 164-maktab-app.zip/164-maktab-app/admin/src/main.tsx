import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient, Session } from '@supabase/supabase-js';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL || '';
const key = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const configured = Boolean(url && key && !url.includes('YOUR_PROJECT'));
const sb = createClient(url || 'https://example.supabase.co', key || 'public-anon-key');
const STAFF_VIEW = '__staff__';
const sections = [
  { label: 'Yangiliklar', table: 'news', fields: [['title','Sarlavha'],['summary','Qisqa matn'],['body','To‘liq matn'],['image_url','Rasm URL']] },
  { label: 'O‘qituvchilar', table: 'teachers', fields: [['full_name','Ism-familiya'],['subject','Fani'],['position','Lavozimi'],['bio','Ma’lumot'],['photo_url','Rasm URL'],['phone_public','Ommaviy telefon']] },
  { label: 'Kutubxona', table: 'library_items', fields: [['title','Kitob nomi'],['author','Muallif'],['category','Turkum'],['description','Tavsif'],['file_url','PDF URL'],['cover_url','Muqova URL']] },
  { label: 'O‘quvchilar kengashi', table: 'council_members', fields: [['full_name','Ism-familiya'],['position','Vazifasi'],['class_name','Sinf'],['bio','Ma’lumot'],['photo_url','Rasm URL']] },
  { label: 'Dars jadvali', table: 'timetable_entries', fields: [['class_name','Sinf'],['weekday','Hafta kuni'],['lesson_number','Dars raqami'],['start_time','Boshlanish (HH:MM)'],['end_time','Tugash (HH:MM)'],['subject','Fan'],['teacher_name','O‘qituvchi'],['room','Xona']] },
  { label: 'To‘garaklar', table: 'clubs', fields: [['name','Nomi'],['category','Yo‘nalish'],['leader_name','Rahbar'],['schedule_text','Jadval'],['description','Tavsif'],['contact','Aloqa']] },
] as const;
type ContentSection = typeof sections[number];
type StaffProfile = { id: string; full_name: string; role: 'director' | 'section_manager' | 'user'; email?: string; };

function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [section, setSection] = useState<ContentSection>(sections[0]);
  const [rows, setRows] = useState<any[]>([]);
  const [form, setForm] = useState<Record<string,string>>({});
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [editing, setEditing] = useState<any>(null);
  const [query, setQuery] = useState('');
  const [permissions, setPermissions] = useState<string[]>([]);
  const [staff, setStaff] = useState<StaffProfile[]>([]);
  const [staffPermissions, setStaffPermissions] = useState<Record<string,string[]>>({});
  const [staffBusy, setStaffBusy] = useState(false);
  const [staffMessage, setStaffMessage] = useState('');
  const [staffError, setStaffError] = useState('');
  const [uploadingField, setUploadingField] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<string>(sections[0].table);

  useEffect(() => {
    sb.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = sb.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => subscription.unsubscribe();
  }, []);
  useEffect(() => {
    if (!session) { setProfile(null); return; }
    sb.from('profiles').select('*').eq('id', session.user.id).single().then(({ data, error: profileError }) => {
      if (profileError) setError(`Profilni yuklab bo‘lmadi: ${profileError.message}`);
      setProfile(data);
    });
  }, [session]);
  useEffect(() => {
    if (!session || !profile || !['director','section_manager'].includes(profile.role)) return;
    loadPermissions();
    if (activeView !== STAFF_VIEW) loadContent();
  }, [session, profile, section, activeView]);

  async function loadPermissions() {
    if (profile?.role === 'director') {
      setPermissions(sections.map(item => item.table));
      return;
    }
    const { data, error: permError } = await sb.from('section_permissions').select('section_key').eq('user_id', session?.user.id).eq('can_manage', true);
    if (permError) { setError(permError.message); return; }
    const allowed = (data || []).map((item: any) => item.section_key);
    setPermissions(allowed);
    if (!allowed.includes(section.table)) {
      const first = sections.find(item => allowed.includes(item.table));
      if (first) setSection(first);
    }
  }
  async function loadContent() {
    setError('');
    const { data, error: loadError } = await sb.from(section.table).select('*').order('created_at', { ascending: false }).limit(200);
    if (loadError) setError(loadError.message);
    setRows(data || []);
  }
  async function loadStaff() {
    setStaffBusy(true); setStaffError(''); setStaffMessage('');
    const [{ data: profiles, error: profilesError }, { data: perms, error: permsError }] = await Promise.all([
      sb.from('profiles').select('id,full_name,role').order('created_at', { ascending: true }),
      sb.from('section_permissions').select('user_id,section_key,can_manage'),
    ]);
    if (profilesError || permsError) {
      setStaffError(profilesError?.message || permsError?.message || 'Ma’lumotlarni yuklab bo‘lmadi.');
      setStaffBusy(false); return;
    }
    setStaff((profiles || []).filter((p: StaffProfile) => p.id !== session?.user.id) as StaffProfile[]);
    const next: Record<string,string[]> = {};
    (perms || []).forEach((p: any) => { if (p.can_manage) next[p.user_id] = [...(next[p.user_id] || []), p.section_key]; });
    setStaffPermissions(next); setStaffBusy(false);
  }
  useEffect(() => { if (activeView === STAFF_VIEW && profile?.role === 'director') loadStaff(); }, [activeView, profile]);

  async function login(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError('');
    const { error: loginError } = await sb.auth.signInWithPassword({ email, password });
    if (loginError) setError(loginError.message);
    setBusy(false);
  }
  async function uploadAsset(field: string, file?: File) {
    if (!file || !session?.user.id) return;
    setError(''); setMessage('');
    const isImage = ['image_url', 'photo_url', 'cover_url'].includes(field);
    const allowed = isImage ? file.type.startsWith('image/') : (file.type === 'application/pdf' || file.type.startsWith('image/'));
    if (!allowed) { setError(isImage ? 'Bu maydonga rasm faylini tanlang.' : 'Bu maydonga PDF yoki rasm faylini tanlang.'); return; }
    if (file.size > 20 * 1024 * 1024) { setError('Fayl hajmi 20 MB dan oshmasligi kerak.'); return; }
    setUploadingField(field);
    const safeName = file.name.normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g, '-');
    const path = `${section.table}/${session.user.id}/${Date.now()}-${safeName}`;
    const { error: uploadError } = await sb.storage.from('school-assets').upload(path, file, { upsert: false, contentType: file.type });
    if (uploadError) {
      setError(`Fayl yuklanmadi: ${uploadError.message}. Supabase’da school-assets bucket va storage siyosatlarini sozlang.`);
      setUploadingField(null); return;
    }
    const { data } = sb.storage.from('school-assets').getPublicUrl(path);
    setForm(old => ({ ...old, [field]: data.publicUrl }));
    setMessage('Fayl yuklandi. Havola tegishli maydonga qo‘yildi; saqlash tugmasini ham bosing.');
    setUploadingField(null);
  }

  async function saveContent(event: React.FormEvent) {
    event.preventDefault(); setMessage(''); setError('');
    const payload: Record<string, any> = {};
    section.fields.forEach(([field]) => { payload[field] = (form[field] || '').trim() || null; });
    payload.published = form.__published !== 'false';
    if (!editing && session?.user.id) payload.created_by = session.user.id;
    const result = editing
      ? await sb.from(section.table).update(payload).eq('id', editing.id)
      : await sb.from(section.table).insert(payload);
    if (result.error) setError(result.error.message);
    else { setMessage(editing ? 'Ma’lumot yangilandi.' : 'Ma’lumot saqlandi.'); setForm({}); setEditing(null); await loadContent(); }
  }
  function startEdit(row: any) {
    setEditing(row); const next: Record<string,string> = {};
    section.fields.forEach(([field]) => { next[field] = row[field] == null ? '' : String(row[field]); });
    next.__published = String(row.published !== false); setForm(next); setMessage(''); setError('');
  }
  async function removeRow(id: string) {
    if (!window.confirm('Ushbu yozuvni o‘chirmoqchimisiz?')) return;
    const { error: deleteError } = await sb.from(section.table).delete().eq('id', id);
    if (deleteError) setError(deleteError.message); else await loadContent();
  }
  async function saveStaffPermissions(person: StaffProfile) {
    setStaffError(''); setStaffMessage(''); setStaffBusy(true);
    const selected = staffPermissions[person.id] || [];
    const nextRole = selected.length ? 'section_manager' : 'user';
    const { error: roleError } = await sb.from('profiles').update({ role: nextRole }).eq('id', person.id);
    if (roleError) { setStaffError(`Rolni saqlab bo‘lmadi: ${roleError.message}`); setStaffBusy(false); return; }
    const { error: deleteError } = await sb.from('section_permissions').delete().eq('user_id', person.id);
    if (deleteError) { setStaffError(`Eski ruxsatlarni yangilab bo‘lmadi: ${deleteError.message}`); setStaffBusy(false); return; }
    if (selected.length) {
      const { error: insertError } = await sb.from('section_permissions').insert(selected.map(section_key => ({ user_id: person.id, section_key, can_manage: true })));
      if (insertError) { setStaffError(`Ruxsatlarni saqlab bo‘lmadi: ${insertError.message}`); setStaffBusy(false); return; }
    }
    setStaffMessage(`${person.full_name || 'Foydalanuvchi'} uchun ruxsatlar saqlandi.`);
    await loadStaff(); setStaffBusy(false);
  }
  const filteredRows = useMemo(() => rows.filter(row => JSON.stringify(row).toLowerCase().includes(query.toLowerCase())), [rows, query]);

  if (!configured) return <div className="center"><div className="login card"><div className="mark">164</div><h1>Admin panel sozlamasi</h1><p><code>admin/.env</code> faylida Supabase URL va anon key qiymatlarini kiriting, so‘ng serverni qayta ishga tushiring.</p></div></div>;
  if (!session) return <div className="center"><form className="login card" onSubmit={login}><div className="mark">164</div><h1>164-MAKTAB</h1><p>Direktor va bo‘lim mas’ullari uchun boshqaruv paneli</p>{error && <div className="error">{error}</div>}<label>Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} /></label><label>Parol<input type="password" required value={password} onChange={e => setPassword(e.target.value)} /></label><button disabled={busy}>{busy ? 'Kirilmoqda…' : 'Tizimga kirish'}</button></form></div>;
  if (!profile) return <div className="center">Profil ma’lumotlari yuklanmoqda…</div>;
  if (!['director','section_manager'].includes(profile.role)) return <div className="center"><div className="card login"><h2>Ruxsat berilmagan</h2><p>Bu akkauntda boshqaruv huquqi yo‘q. Direktor bilan bog‘laning.</p><button onClick={() => sb.auth.signOut()}>Chiqish</button></div></div>;

  return <div className="shell"><aside><div className="brand"><span className="mark small">164</span><div><b>164-MAKTAB</b><small>ADMIN PANEL</small></div></div><div className="user"><b>{profile.full_name || session.user.email}</b><small>{profile.role === 'director' ? 'Direktor' : 'Bo‘lim mas’uli'}</small></div><nav>{sections.filter(item => permissions.includes(item.table)).map(item => <button key={item.table} className={activeView === item.table ? 'selected' : ''} onClick={() => { setSection(item); setActiveView(item.table); setForm({}); setEditing(null); setError(''); setMessage(''); }}>{item.label}</button>)}{profile.role === 'director' && <button className={activeView === STAFF_VIEW ? 'selected' : ''} onClick={() => { setActiveView(STAFF_VIEW); setError(''); }}>Xodimlar va ruxsatlar</button>}</nav><button className="logout" onClick={() => sb.auth.signOut()}>Chiqish ↗</button></aside>
    <main><header><div><small>164-MAKTAB / BOSHQARUV</small><h1>{activeView === STAFF_VIEW ? 'Xodimlar va ruxsatlar' : section.label}</h1></div><span className="status">● Tizimga kirilgan</span></header>
      {activeView === STAFF_VIEW && profile.role === 'director' ? <div className="content"><div className="card tablecard"><div className="tabletitle"><div><h2>Bo‘lim mas’ullarini tayinlash</h2><p className="muted">Akkauntlar Supabase Authentication orqali yaratiladi. Bu yerda mavjud foydalanuvchilarning bo‘lim ruxsatlarini belgilang.</p></div><button className="secondary" onClick={loadStaff}>Yangilash ↻</button></div>{staffError && <div className="error">{staffError}</div>}{staffMessage && <div className="success">{staffMessage}</div>}{staffBusy && <p className="muted">Ma’lumotlar yuklanmoqda…</p>}{!staffBusy && staff.length === 0 && <p className="empty">Boshqa foydalanuvchi profillari topilmadi. Avval Supabase Authentication → Users bo‘limida mas’ul xodim uchun akkaunt yarating.</p>}{staff.map(person => <div className="staff-row" key={person.id}><div className="staff-heading"><div><b>{person.full_name || 'Ism kiritilmagan'}</b><small>{person.id}</small></div><span className={`badge ${person.role === 'section_manager' ? 'manager-badge' : ''}`}>{person.role === 'section_manager' ? 'Bo‘lim mas’uli' : 'Oddiy foydalanuvchi'}</span></div><div className="permission-grid">{sections.map(item => <label key={item.table} className="permission-option"><input type="checkbox" checked={(staffPermissions[person.id] || []).includes(item.table)} onChange={event => setStaffPermissions(old => ({ ...old, [person.id]: event.target.checked ? [...(old[person.id] || []), item.table] : (old[person.id] || []).filter(key => key !== item.table) }))} />{item.label}</label>)}</div><button disabled={staffBusy} onClick={() => saveStaffPermissions(person)}>Ruxsatlarni saqlash</button></div>)}</div><p className="foot">164-MAKTAB · Urgut tumani · Ruxsatlarni faqat direktor boshqaradi.</p></div> : <div className="content"><div className="formcard card"><h2>{editing ? 'Ma’lumotni tahrirlash' : 'Yangi ma’lumot qo‘shish'}</h2><form onSubmit={saveContent}><div className="fields">{section.fields.map(([field,label]) => <label key={field}>{label}{['body','description','bio','summary'].includes(field) ? <textarea rows={3} value={form[field] || ''} onChange={event => setForm({ ...form, [field]: event.target.value })} /> : <input required={['title','full_name','name','class_name','weekday','subject'].includes(field)} type="text" value={form[field] || ''} onChange={event => setForm({ ...form, [field]: event.target.value })} />}{['image_url','photo_url','cover_url','file_url'].includes(field) && <><div className="upload-row"><input aria-label={`${label} faylini tanlash`} type="file" accept={field === 'file_url' ? '.pdf,application/pdf,image/*' : 'image/*'} disabled={uploadingField === field} onChange={event => { const file = event.target.files?.[0]; void uploadAsset(field, file); event.currentTarget.value = ''; }} /><small>{uploadingField === field ? 'Yuklanmoqda…' : 'Rasm yoki faylni yuklang (20 MB gacha)'}</small></div>{form[field] && <a className="asset-link" href={form[field]} target="_blank" rel="noreferrer">Yuklangan faylni ko‘rish ↗</a>}</>}</label>)}</div>{error && <div className="error">{error}</div>}{message && <div className="success">{message}</div>}<label className="publish-toggle"><input type="checkbox" checked={form.__published !== 'false'} onChange={event => setForm({ ...form, __published: String(event.target.checked) })} /> Ommaga ko‘rsatish</label><div className="form-actions"><button type="submit">{editing ? 'O‘zgarishlarni saqlash' : '+ Saqlash'}</button>{editing && <button type="button" className="secondary" onClick={() => { setEditing(null); setForm({}); }}>Bekor qilish</button>}</div></form></div><div className="card tablecard"><div className="tabletitle"><h2>Joylashtirilgan ma’lumotlar</h2><div className="tabletools"><input className="search" placeholder="Qidirish…" value={query} onChange={event => setQuery(event.target.value)} /><button className="secondary" onClick={loadContent}>Yangilash ↻</button></div></div>{error && <div className="error">{error}</div>}{filteredRows.length === 0 ? <p className="empty">Hozircha ma’lumot yo‘q. Yuqoridagi shakldan birinchi yozuvni qo‘shing.</p> : <div className="tablewrap"><table><thead><tr><th>Ma’lumot</th><th>Holat</th><th>Amallar</th></tr></thead><tbody>{filteredRows.map(row => <tr key={row.id}><td><b>{row.title || row.full_name || row.name || `${row.class_name || ''} ${row.subject || ''}`}</b><small>{row.summary || row.category || row.position || row.weekday || row.description || ''}</small></td><td><span className="badge">{row.published === false ? 'Qoralama' : 'Faol'}</span></td><td><div className="row-actions"><button className="secondary" onClick={() => startEdit(row)}>Tahrirlash</button><button className="danger" onClick={() => removeRow(row.id)}>O‘chirish</button></div></td></tr>)}</tbody></table></div>}</div><p className="foot">164-MAKTAB · Urgut tumani · Bilim, innovatsiya va taraqqiyot sari!</p></div>}
    </main></div>;
}

createRoot(document.getElementById('root')!).render(<App />);
