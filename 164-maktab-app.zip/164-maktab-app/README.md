# 164-MAKTAB — Mobil ilova va boshqaruv paneli (MVP, 9-bosqich)

164-MAKTAB uchun o‘zbek tilidagi Android/iOS mobil ilovasi, veb-admin panel va Supabase ma’lumotlar bazasi boshlang‘ich loyihasi.

## Loyiha tarkibi
- `mobile/` — Expo + React Native ilovasi (Android/iOS; Expo Go orqali dastlabki sinov).
- `admin/` — Vite + React boshqaruv paneli.
- `supabase/schema.sql` — jadvallar, foydalanuvchi rollari, bo‘lim ruxsatlari va Row Level Security siyosatlari.



## 7-bosqich: direktor uchun xodimlar va bo‘lim ruxsatlari
- Direktor panelida “Xodimlar va ruxsatlar” bo‘limi qo‘shildi.
- Mavjud profillar ro‘yxatini ko‘rish va ularga kontent bo‘limlarini biriktirish mumkin.
- Kamida bitta bo‘lim biriktirilgan profil `section_manager`, bo‘limlari olib tashlangan profil `user` roliga o‘tadi.
- Direktorning o‘z profili ro‘yxatdan chiqarilgan; bu sahifa faqat `director` roliga ko‘rinadi.
- Xavfsizlik uchun yangi foydalanuvchi akkauntlari Supabase Authentication’da yaratiladi; service-role kaliti frontendga qo‘yilmaydi.

## 6-bosqich: dars jadvali, kengash va to‘garaklar interfeysi
- Dars jadvalida sinf nomi bo‘yicha filtrlash (masalan, 7-A).
- Dushanbadan shanbagacha kun tanlash.
- Dars raqami, fan, o‘qituvchi, boshlanish/tugash vaqti hamda xona uchun alohida kartalar.
- O‘quvchilar kengashi a’zolari uchun rasm/bosh harf avatari, vazifasi, sinfi va qisqacha ma’lumot.
- To‘garaklar uchun yo‘nalish, tavsif, rahbar, mashg‘ulot vaqti va aloqa ma’lumotlari ko‘rinishi.

## 5-bosqich: o‘qituvchi profillari va elektron kutubxona
- O‘qituvchi kartalarida foto yoki bosh harflardan tuzilgan o‘rinbosar avatar.
- Fan, lavozim, tarjimai hol va ixtiyoriy ommaviy telefon raqami.
- Elektron kutubxonada muqova, muallif, kategoriya, tavsif va faylni ochish havolasi.
- Muqova yoki foto bo‘lmagan holatlar uchun brendga mos o‘rinbosar dizayn.

## 4-bosqich: yangiliklar tajribasi
- Yangiliklar ro‘yxati rasm, sarlavha, qisqa matn va sana bilan kartalar ko‘rinishida.
- Yangilik tafsilotlari uchun alohida sahifa/modal.
- Yangilik matnini qurilmaning ulashish menyusi orqali yuborish.
- Elektron kutubxonadagi fayl havolalarini tashqi ilovada ochish.
- Rasm URL berilmaganida maktab brendiga mos o‘rinbosar ko‘rinish.

## 3-bosqich: mobil interfeys dizayni
- Ko‘k-oltin ranglar asosida maktab brendiga mos bosh ekran.
- Bo‘lim kartalarining faol holati va qisqa izohlari.
- Bo‘lim ichidagi qidiruv, natijalar soni va bo‘sh natija holati.
- Qidiruvni tozalash va bo‘lim almashtirilganda qidiruvni tiklash.
- Maktab portali yorlig‘i; soxta real-vaqt onlayn soni ko‘rsatilmaydi.

## 2-bosqichda qo‘shilgan imkoniyatlar
- Admin panelda ma’lumot qo‘shish, tahrirlash va o‘chirish.
- Ma’lumotni ommaga chiqarish yoki qoralama holatida saqlash.
- Joylashtirilgan yozuvlarni qidirish.
- Bo‘lim mas’uliga faqat biriktirilgan bo‘limlarni ko‘rsatish.
- SQL sxemasiga profil rolini tekshiruvchi `current_user_role()` funksiyasi qo‘shildi.

## Talablar
- Node.js 20 yoki undan yangisi
- Supabase hisob qaydnomasi va loyiha
- Android sinovi uchun Expo Go; iOS sinovi uchun iPhone’dagi Expo Go yoki macOS/Xcode

## 1. Supabase bazasini sozlash
1. https://supabase.com saytida yangi loyiha yarating.
2. Supabase Dashboard → SQL Editor bo‘limida `supabase/schema.sql` faylining to‘liq mazmunini ishga tushiring.
3. Project Settings → API bo‘limidan Project URL va anon/public key’ni oling.
4. `mobile/.env.example` nusxasini `mobile/.env` nomi bilan, `admin/.env.example` nusxasini `admin/.env` nomi bilan saqlang va tegishli qiymatlarni kiriting.
5. Supabase Authentication orqali direktor uchun foydalanuvchi yarating. Keyin SQL Editor’da emailni almashtirib quyidagini bajaring:

```sql
update public.profiles
set role = 'director', full_name = 'Maktab direktori'
where id = (select id from auth.users where email = 'admin@example.com');
```

Agar profil yaratilmagan bo‘lsa:

```sql
insert into public.profiles (id, full_name, role)
select id, 'Maktab direktori', 'director'
from auth.users where email = 'admin@example.com'
on conflict (id) do update set role = 'director';
```

Bo‘lim mas’uli tayinlash: foydalanuvchi Authentication’da yaratilgach, uning `profiles` jadvalidagi `role` qiymatini `section_manager` qiling va `section_permissions` jadvaliga kerakli bo‘lim uchun ruxsat yozuvini qo‘shing. `section_key` qiymatlari: `news`, `teachers`, `library_items`, `council_members`, `timetable_entries`, `clubs`.

## 2. Mobil ilovani ishga tushirish
```bash
cd mobile
cp .env.example .env
npm install
npx expo start
```
Terminalda ko‘rsatilgan QR kodni Expo Go bilan skanerlang.

## 3. Admin panelni ishga tushirish
```bash
cd admin
cp .env.example .env
npm install
npm run dev
```
Terminal ko‘rsatgan mahalliy manzilni brauzerda oching va Supabase’da yaratilgan akkaunt bilan kiring.

## Rollar va xavfsizlik
- `director` — barcha kontent bo‘limlarini boshqaradi.
- `section_manager` — `section_permissions` jadvalida biriktirilgan bo‘limlarnigina boshqaradi.
- `user` — oddiy foydalanuvchi; kontent boshqarish huquqi yo‘q.
- Frontend’da faqat Supabase anon/public key ishlatiladi. `service_role` kalitini mobil ilovaga yoki veb-panelga hech qachon joylamang.

## 8-bosqich: admin paneldan rasm va PDF yuklash
- Yangilik, o‘qituvchi, kengash a’zosi va kitob uchun faylni to‘g‘ridan-to‘g‘ri admin paneldan tanlash mumkin.
- Rasmlar `image_url`, `photo_url`, `cover_url` maydonlariga, PDF yoki rasm esa kutubxonaning `file_url` maydoniga yuklanadi.
- Fayl 20 MB bilan cheklangan; rasm maydonlari faqat rasm, kitob fayli esa PDF yoki rasm qabul qiladi.
- Yuklash tugagach hosil bo‘lgan havola shaklga qo‘yiladi; yozuvni yakunlash uchun “Saqlash” tugmasini bosing.
- `supabase/schema.sql` ichiga `school-assets` Storage bucket va bo‘limga bog‘langan yuklash/o‘zgartirish/o‘chirish siyosatlari qo‘shildi.
- Bucket ommaviy o‘qish uchun mo‘ljallangan: unga joylangan nashrga yaroqli fayllar URL’ini bilgan har kim ochishi mumkin. Maxfiy hujjatlar uchun ishlatmang.
- Ushbu yangilanish ishlashi uchun Supabase SQL Editor’da yangilangan `schema.sql` faylini qayta ishga tushiring.



## 9-bosqich: mobil ma’lumotlarni yuklash barqarorligi
- Ma’lumotlar jadval turiga mos tartibda olinadi: yangiliklar sanasi, o‘qituvchilar va kitoblar nomi, dars jadvali dars raqami bo‘yicha.
- Supabase sozlangan holatda bo‘sh jadvalga demo ma’lumotlar aralashtirib ko‘rsatilmaydi.
- Ma’lumotlarni olish xatosi foydalanuvchiga ko‘rsatiladi va qayta urinish tugmasi beriladi.
- Sinov rejimida namunaviy ma’lumotlar ko‘rsatilishi aniq ogohlantirish bilan ajratiladi.
- Mobil paket versiyasi 1.7.0 ga yangilandi.

## Tekshiruv holati
- `mobile/App.tsx` TypeScript/JSX transpile/sintaksis tekshiruvi: 0 ta sintaktik xato.
- `admin/src/main.tsx` TypeScript/JSX transpile/sintaksis tekshiruvi: 0 ta sintaktik xato.
- Admin panelga direktor uchun xodim va bo‘lim ruxsatlarini boshqarish interfeysi qo‘shildi.
- Yangiliklar kartalari, tafsilot oynasi, sana formatlash va ulashish funksiyalari kodga qo‘shildi.
- Paketlar o‘rnatilmaganligi sababli to‘liq TypeScript type-check, Expo build va qurilma sinovi bu muhitda bajarilmadi.

## Muhim holat
Bu — ishlab chiqish uchun MVP. Joriy muhitda paketlarni o‘rnatish va qurilma emulyatori mavjud bo‘lmagani sababli to‘liq `npm run build`, Expo build va haqiqiy qurilma sinovi bajarilmadi; loyiha sizning kompyuteringizda `npm install` va testlardan o‘tkazilishi kerak. Supabase’ga ulanmagan bo‘lsa, haqiqiy ma’lumotlar ko‘rinmaydi. Rasmiy maktab logotipi, haqiqiy kontent, parolni tiklash, push-bildirishnomalar, fayl saqlash siyosati, maxfiylik bayonoti va imzolangan Android/iOS yig‘ilmalari keyingi bosqichlarda sozlanadi.
