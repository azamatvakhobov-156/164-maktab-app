-- 164-MAKTAB starter schema for Supabase (PostgreSQL)
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'user' check (role in ('director','section_manager','user')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.section_permissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  section_key text not null check (section_key in ('news','teachers','library_items','council_members','timetable_entries','clubs')),
  can_manage boolean not null default true,
  unique(user_id, section_key)
);

create or replace function public.has_section_access(section text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'director')
    or exists(select 1 from public.profiles p join public.section_permissions sp on sp.user_id=p.id
      where p.id=auth.uid() and p.role='section_manager' and sp.section_key=section and sp.can_manage=true);
$$;

create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_director()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='director');
$$;

create table if not exists public.news (
  id uuid primary key default gen_random_uuid(), title text not null, summary text, body text,
  image_url text, published boolean not null default true, published_at timestamptz default now(),
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.teachers (
  id uuid primary key default gen_random_uuid(), full_name text not null, subject text, position text, bio text,
  photo_url text, phone_public text, published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.library_items (
  id uuid primary key default gen_random_uuid(), title text not null, author text, category text, description text,
  file_url text, cover_url text, published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.council_members (
  id uuid primary key default gen_random_uuid(), full_name text not null, position text, class_name text, bio text,
  photo_url text, published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.timetable_entries (
  id uuid primary key default gen_random_uuid(), class_name text not null, weekday text not null,
  lesson_number integer not null check (lesson_number between 1 and 12), start_time time, end_time time,
  subject text not null, teacher_name text, room text, published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(class_name, weekday, lesson_number)
);
create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(), name text not null, category text, leader_name text,
  schedule_text text, description text, contact text, published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.club_sessions (
  id uuid primary key default gen_random_uuid(), club_id uuid not null references public.clubs(id) on delete cascade,
  weekday text, start_time time, end_time time, room text, notes text, created_at timestamptz not null default now()
);

-- Create profile for each new authenticated user. New users have no management rights by default.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.section_permissions enable row level security;
alter table public.news enable row level security;
alter table public.teachers enable row level security;
alter table public.library_items enable row level security;
alter table public.council_members enable row level security;
alter table public.timetable_entries enable row level security;
alter table public.clubs enable row level security;
alter table public.club_sessions enable row level security;

-- Profiles: users can read/update their own basic profile; only director manages role assignments.
drop policy if exists "profiles read own or director" on public.profiles;
create policy "profiles read own or director" on public.profiles for select using (id=auth.uid() or public.is_director());
drop policy if exists "profiles update own basic" on public.profiles;
create policy "profiles update own basic" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid() and role = public.current_user_role());
drop policy if exists "director manages profiles" on public.profiles;
create policy "director manages profiles" on public.profiles for all using (public.is_director()) with check (public.is_director());

drop policy if exists "permissions read self or director" on public.section_permissions;
create policy "permissions read self or director" on public.section_permissions for select using (user_id=auth.uid() or public.is_director());
drop policy if exists "director manages permissions" on public.section_permissions;
create policy "director manages permissions" on public.section_permissions for all using (public.is_director()) with check (public.is_director());

-- Public can read published content. Authenticated managers can manage only assigned sections; director can manage all.
do $$ declare t text; begin
 foreach t in array array['news','teachers','library_items','council_members','timetable_entries','clubs'] loop
  execute format('drop policy if exists %I on public.%I','public read published '||t,t);
  execute format('create policy %I on public.%I for select using (published = true or public.has_section_access(%L))','public read published '||t,t,t);
  execute format('drop policy if exists %I on public.%I','managers insert '||t,t);
  execute format('create policy %I on public.%I for insert to authenticated with check (public.has_section_access(%L))','managers insert '||t,t,t);
  execute format('drop policy if exists %I on public.%I','managers update '||t,t);
  execute format('create policy %I on public.%I for update to authenticated using (public.has_section_access(%L)) with check (public.has_section_access(%L))','managers update '||t,t,t,t);
  execute format('drop policy if exists %I on public.%I','managers delete '||t,t);
  execute format('create policy %I on public.%I for delete to authenticated using (public.has_section_access(%L))','managers delete '||t,t,t);
 end loop;
end $$;

drop policy if exists "public read club sessions" on public.club_sessions;
create policy "public read club sessions" on public.club_sessions for select using (exists(select 1 from public.clubs c where c.id=club_id and c.published=true));
drop policy if exists "managers manage club sessions" on public.club_sessions;
create policy "managers manage club sessions" on public.club_sessions for all to authenticated using (public.has_section_access('clubs')) with check (public.has_section_access('clubs'));

create index if not exists news_published_created_idx on public.news(published, created_at desc);
create index if not exists teachers_published_name_idx on public.teachers(published, full_name);
create index if not exists library_published_title_idx on public.library_items(published, title);
create index if not exists timetable_lookup_idx on public.timetable_entries(class_name, weekday, lesson_number);
create index if not exists clubs_published_idx on public.clubs(published, name);


-- Public school media bucket. Public URLs are used for published news images,
-- teacher photos, library covers and downloadable public PDF resources.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('school-assets', 'school-assets', true, 20971520,
        array['image/jpeg','image/png','image/webp','image/gif','application/pdf'])
on conflict (id) do update set public=true, file_size_limit=20971520,
  allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','application/pdf'];

drop policy if exists "school assets managers can upload" on storage.objects;
create policy "school assets managers can upload" on storage.objects
for insert to authenticated with check (
  bucket_id='school-assets' and public.has_section_access((storage.foldername(name))[1])
  and (storage.foldername(name))[2] = auth.uid()::text
);
drop policy if exists "school assets managers can update own uploads" on storage.objects;
create policy "school assets managers can update own uploads" on storage.objects
for update to authenticated using (
  bucket_id='school-assets' and public.has_section_access((storage.foldername(name))[1])
  and (storage.foldername(name))[2] = auth.uid()::text
) with check (
  bucket_id='school-assets' and public.has_section_access((storage.foldername(name))[1])
  and (storage.foldername(name))[2] = auth.uid()::text
);
drop policy if exists "school assets managers can delete own uploads" on storage.objects;
create policy "school assets managers can delete own uploads" on storage.objects
for delete to authenticated using (
  bucket_id='school-assets' and public.has_section_access((storage.foldername(name))[1])
  and (storage.foldername(name))[2] = auth.uid()::text
);
